//
//  ViewController.swift
//  saleForce_Notify
//
//  Created by nextage on 2021/07/09.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

